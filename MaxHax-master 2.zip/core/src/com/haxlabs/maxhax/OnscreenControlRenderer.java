package com.haxlabs.maxhax;

public class OnscreenControlRenderer {

	public OnscreenControlRenderer() {
		// TODO Auto-generated constructor stub
	}

}
